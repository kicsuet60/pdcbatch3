// console.log("hello");
// alert("Hello");

// Variables
// let age = 24;
// const pi = 3.14;
// age = 25;
// pi = 17; // constant
// var year = 22;
// console.log(typeof pi);
