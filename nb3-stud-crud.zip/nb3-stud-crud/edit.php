<?php

$id = ( !empty($_GET['id']) ) ? $_GET['id']: "";
$name = ( !empty($_GET['name']) ) ? $_GET['name']: "";


$query = "UPDATE student SET name = '$name' WHERE ID = $id";
$hostname = 'localhost';
$db_name = 'crud_db';
$username = 'root';
$password = '';

try{

    $db = new mysqli($hostname, $username, $password, $db_name);

    if ($db->query($query) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $db->error;
    }

    //close the connection to DB
    $db->close();


}catch(Exception $e)
{
    $error_message = $e->getMessage();
    echo "<p>Error message: $error_message </p>";
}

?>