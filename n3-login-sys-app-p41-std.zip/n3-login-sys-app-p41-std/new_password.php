<?php $currentPage = "New Password"; ?>
<?php require_once('includes/header.php') ?>
	<section class="fxt-template-animation fxt-template-layout1">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6 col-12 fxt-bg-color">
					<div class="fxt-content">
						<div class="fxt-header">
							<a href="login-1.php" class="fxt-logo"><img src="img/logo-1.png" alt="Logo"></a>
							<div class="fxt-page-switcher">
								<a href="login-1.php" class="switcher-text1">Log In</a>
								<a href="register-1.php" class="switcher-text1">Register</a>
							</div>
						</div>
						<div class="fxt-form">
							<h2>New Password</h2>
							<p>Password updated successfully</p>
							<form action="" method="POST">
                                 <div class="form-group">
									<div class="fxt-transformY-50 fxt-transition-delay-1">
										<input type="password" class="form-control" name="new-password" placeholder="New Password" required="required">
										<i class="flaticon-padlock"></i>
									</div>
								</div>
                                 <div class="form-group">
									<div class="fxt-transformY-50 fxt-transition-delay-2">
										<input type="password" class="form-control" name="confirm-new-password" placeholder="Confirm new password" required="required">
										<i class="flaticon-padlock"></i>
									</div>
								</div>
                                <div class="form-group">
                                    <div class="fxt-transformY-50 fxt-transition-delay-3">
                                        <button type="input-submit" class="fxt-btn-fill" name="password-recovery">Reset</button>
                                    </div>
                                </div>
							</form>
						</div>
						<div class="fxt-footer">
							<ul class="fxt-socials">
								<li class="fxt-facebook fxt-transformY-50 fxt-transition-delay-3"><a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="fxt-twitter fxt-transformY-50 fxt-transition-delay-4"><a href="#" title="twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="fxt-google fxt-transformY-50 fxt-transition-delay-5"><a href="#" title="google"><i class="fab fa-google-plus-g"></i></a></li>
								<li class="fxt-linkedin fxt-transformY-50 fxt-transition-delay-6"><a href="#" title="linkedin"><i class="fab fa-linkedin-in"></i></a></li>
								<li class="fxt-pinterest fxt-transformY-50 fxt-transition-delay-8">
									<a href="#" title="pinterest"><i class="fab fa-pinterest-p"></i></a>
								</li>
							</ul>
							<h5 class="mt-4 fxt-transformY-50 fxt-transition-delay-10"">Tahir <span style="color:red;">Shafi</span>  &nbsp;&nbsp;&nbsp;<i class="fa fa-mobile"></i> +92 334 1068 817</h5>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-12 fxt-none-767 fxt-bg-img" data-bg-image="img/figure/bg1-l.jpg"></div>
			</div>
		</div>
	</section>
	<?php require_once('includes/footer.php') ?>