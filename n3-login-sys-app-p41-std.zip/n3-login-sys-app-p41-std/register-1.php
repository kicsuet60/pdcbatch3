<?php 
$currentPage = "Sign UP";
require_once("includes/header.php");

if(isset($_POST["sign-up"])){
 
	$first_name     = escape($_POST['first_name']); 
	$last_name      = escape($_POST['last_name']);
	$user_name      = escape($_POST['user_name']);
	$user_email     = escape($_POST['user_email']);
	$user_pass      = escape($_POST['user_password']);
	$user_con_pass  = escape($_POST['user_confirm_password']);

	//first name validation
	$pattern_fn = "/^[a-zA-Z ]{3,12}$/";
	if(!preg_match($pattern_fn, $first_name)) {
		$errFn = "Must be at lest 3 character long, letter and space allowed";
	}

	//last name validation
	$pattern_ln = "/^[a-zA-Z ]{3,12}$/";
	if(!preg_match($pattern_ln, $last_name)) {
		$errLn = "Must be at lest 3 character long, letter and space allowed";
	}

	//user name validation
	$pattern_un = "/^[a-zA-Z0-9_]{3,16}$/";
	if(!preg_match($pattern_un, $user_name)) {
		$errUn = "Must be at lest 3 character long, letter, number and underscore allowed";
	}

	//email validation
	$pattern_ue = "/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/i";
	if(!preg_match($pattern_ue, $user_email)) {
		$errUe = "Invalid format of email";

	}

	if($user_pass == $user_con_pass) {
		//password validation
		$pattern_up = "/^.*(?=.{4,56})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).*$/";
		if(!preg_match($pattern_up, $user_pass)) {
			$errPass = "Must be at lest 4 character long, 1 upper case, 1 lower case letter and 1 number exist";
		}
	} else {
		$errPass = "Password dosen't matched";
	}    
	
	if(!isset($errFn) && !isset($errLn) && !isset($errUn) && !isset($errUe) && !isset($errPass) && !isset($errCaptcha)){
		$hash = password_hash($user_pass, PASSWORD_BCRYPT, ['cost'=>10]);
		date_default_timezone_set("asia/karachi");
		$date = date("Y-m-d H:i:s");
		
		$query = "INSERT INTO users (first_name, last_name, user_name, user_email, user_password, validation_key, registration_date) VALUES ('$first_name', '$last_name', '$user_name', '$user_email', '$hash', 0, '$date')";
		$query_conn = mysqli_query($connection, $query);
		if(!$query_conn) {
			die("Query failed" . mysqli_error($connection));
		} else {
			echo "<div class='notification'>Sign up successful</div>";
		}
	}

} // closing signup
?>
	<section class="fxt-template-animation fxt-template-layout1">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6 col-12 fxt-bg-color">
					<div class="fxt-content">
						<div class="fxt-header">
							<a href="login-1.php" class="fxt-logo"><img src="img/logo-1.png" alt="Logo"></a>
							<div class="fxt-page-switcher">
								<a href="login-1.php" class="switcher-text1">Log In</a>
								<a href="register-1.php" class="switcher-text1 active">Register</a>
							</div>
						</div>
						<div class="fxt-form">
							<h2>Register</h2>
							<p>Create an account free and enjoy it</p>
							<form action="" method="POST">
							<div class="form-group fxt-transformY-50 fxt-transition-delay-1">
									<div class="position-relative">
										<input type="text" class="form-control" name="first_name" placeholder="First Name" required="required">
										<i class="flaticon-user"></i>			
									</div>									
									<?php echo isset($errFn)?"<span class='error text-danger'>{$errFn}</span>":""; ?>					
								</div>
								<div class="form-group fxt-transformY-50 fxt-transition-delay-2">
									<div class="position-relative">
										<input type="text" class="form-control" name="last_name" placeholder="Last name" required="required">
										<i class="flaticon-user"></i>										
									</div>
									<?php echo isset($errLn)?"<span class='error text-danger'>{$errLn}</span>":""; ?>
								</div>
								<div class="form-group fxt-transformY-50 fxt-transition-delay-3">
									<div class="position-relative">
										<input type="text" class="form-control" name="user_name" placeholder="User name" required="required">
										<i class="flaticon-user"></i>
									</div>									
									<?php echo isset($errUn)?"<span class='error text-danger'>{$errUn}</span>":""; ?>
								</div>
								<div class="form-group fxt-transformY-50 fxt-transition-delay-3">
									<div class="position-relative">
										<input type="email" class="form-control" name="user_email" placeholder="Email Address" required="required">
										<i class="flaticon-envelope"></i>
									</div>
									<?php echo isset($errUn)?"<span class='error text-danger'>{$errUn}</span>":""; ?>
								</div>
								<div class="form-group fxt-transformY-50 fxt-transition-delay-4">
									<div class="position-relative">
										<input type="password" class="form-control" name="user_password" placeholder="Password" required="required">
										<i class="flaticon-padlock"></i>
									</div>
									<?php echo isset($errPass)?"<span class='error text-danger'>{$errPass}</span>":"" ?>
								</div>
								<div class="form-group fxt-transformY-50 fxt-transition-delay-5">
									<div class="position-relative">
										<input type="password" class="form-control" name="user_confirm_password" placeholder="Confirm Password" required="required">
										<i class="flaticon-padlock"></i>
									</div>
									<?php echo isset($errPass)?"<span class='error text-danger'>{$errPass}</span>":"" ?>
								</div>
								<div class="form-group fxt-transformY-50 fxt-transition-delay-6">
									<div class="position-relative">
										<button type="submit" class="fxt-btn-fill" name="sign-up">Register</button>
									</div>
								</div>
							</form>
						</div>
						<div class="fxt-footer">
							<ul class="fxt-socials">
								<li class="fxt-facebook fxt-transformY-50 fxt-transition-delay-5"><a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li class="fxt-twitter fxt-transformY-50 fxt-transition-delay-6"><a href="#" title="twitter"><i class="fab fa-twitter"></i></a></li>
								<li class="fxt-google fxt-transformY-50 fxt-transition-delay-7"><a href="#" title="google"><i class="fab fa-google-plus-g"></i></a></li>
								<li class="fxt-linkedin fxt-transformY-50 fxt-transition-delay-8"><a href="#" title="linkedin"><i class="fab fa-linkedin-in"></i></a></li>
								<li class="fxt-pinterest fxt-transformY-50 fxt-transition-delay-8">
									<a href="#" title="pinterest"><i class="fab fa-pinterest-p"></i></a>
								</li>		
							</ul>
							<h5 class="mt-4 fxt-transformY-50 fxt-transition-delay-10"">Tahir <span style="color:red;">Shafi</span>  &nbsp;&nbsp;&nbsp;<i class="fa fa-mobile"></i> +92 334 1068 817</h5>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-12 fxt-none-767 fxt-bg-img" data-bg-image="img/figure/bg1-r.jpg"></div>
			</div>
		</div>
	</section>
<?php require_once('includes/footer.php') ?>