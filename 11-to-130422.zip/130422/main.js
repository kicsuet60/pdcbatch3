// null & undefined
// let age = null;
// console.log(age, age + 3, `user age ${age}`);

// boolean >> true false
// console.log(true, false, "true", "false");

// let email = "tahir.shafi@kics.edu.pk";
// let result = email.includes("g");

// console.log(result);

//Comparision Operator
// let age = 20;
// console.log(age == 20);
// console.log(age == 25);
// console.log(age != 20);
// console.log(age != 25);
// console.log(age < 25);
// console.log(age > 25);
// console.log(age <= 25);
// console.log(age >= 25);

// console.log(age !== "20");
// console.log(age !== 20);

// functions and methods
// const sayHello = function (name = "user") {
//   console.log(`Hello Web ${name}`);
// };

// sayHello();
