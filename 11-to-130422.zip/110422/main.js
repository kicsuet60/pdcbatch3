// let students = ["arif", "asif", "tariq"];
// console.log(students);
// console.log(students[2]);
// students[1] = "arsalan";
// console.log(students[1]);
// console.log(students);

// let ages = ["ali", "adil", 30, 20];
// console.log(ages[1]);
// console.log(students.length);
// let result = students.join(",");
// let result = students.join("-");
// let result = students.indexOf("asif");
// console.log(result);

// For Loop
for (let i = 1; i < 6; i++) {
  console.log("For Loop in", i);
}

let ages = ["ali", "adil", 30, 20];
