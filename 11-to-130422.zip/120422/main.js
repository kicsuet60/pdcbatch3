// let students = ["arif", "asif", "tariq"];
// console.log(students);
// console.log(students[2]);
// students[1] = "arsalan";
// console.log(students[1]);
// console.log(students);

// let ages = ["ali", "adil", 30, 20];
// console.log(ages[1]);
// console.log(students.length);
// let result = students.join(",");
// let result = students.join("-");
// let result = students.indexOf("asif");
// console.log(result);

// For Loop
// for (let i = 1; i < 6; i++) {
//   console.log("For Loop in", i);
// }

// let students = ["arif", "asif", "tariq", "adil"];

// for (let i = 0; i < students.length; i++) {
//   console.log("Saud Gramerly Okay:", i);
// }

// html template for loop
// let heading = "course content";
// let courses = ["HTML5", "saud", "CSS3", "Javascript", "es6", "REACT 😱"];
// let html = `<h2>${heading}</h2><ul>`;

for (let course of courses) {
  html += `<li>${course}</li>`;
}

// html += `</ul>`;

// document.getElementById("call_html").innerHTML = html;

/////////////////////////////////////////////////////////
// let students = ["arif", "asif", "tariq", "adil"];
// for (const student of students) {
//   console.log(student);
// }
