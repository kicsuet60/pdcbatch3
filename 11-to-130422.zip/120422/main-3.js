// if condition
// const stdAge = 25.2;

// if (stdAge <= 25) {
//   console.log("your age:", stdAge);
// }

// const pwd = "p@sswo";
// if (pwd.length > 8) {
//   console.log("this password okay");
// } else {
//   console.log("this password not okay");
// }

const pwd = "";

let pwdLenght = pwd.length;

if (pwdLenght > 8 <= 13) {
  console.log("that password is strong enough");
}
// } else if (pwdLenght >= 8) {
//   console.log("that password accepted but less secure!");
// } else {
//   console.log("that password is not long enough");
// }
