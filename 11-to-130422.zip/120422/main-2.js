// While Loop
// let i = 1;
// while (i < 6) {
//   console.log("While Loop in", i);
//   i++;
// }

// const names = ["asif", "arif", "tariq"];
// let i = 0;
// while (i < names.length) {
//   console.log(names[i]);
//   i++;
// }

//////////////////////////////////////////////////////////////////

// do while

// let i = 6;
// do {
//   console.log("Do While Loop", i);
//   i++;
// } while (i < 5);
