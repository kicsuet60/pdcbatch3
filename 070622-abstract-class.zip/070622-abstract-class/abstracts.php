<!-- An abstract class is a class that has at least one abstract method. Abstract methods can only have names and arguments, and no other code. Thus, we cannot create objects out of abstract classes. Instead, we need to create child classes that add the code into the bodies of the methods, and use these child classes to create objects -->

<?php
abstract class Car{
    private $model = "Audi";
    abstract public function color();
    abstract public function door();
    public function __construct(){
        echo "constructor <br/>";
        $this->concrete();
    }
    public function concrete(){
        echo "concrete <br/>";
    }   
        
}

class Audi extends Car {
    public function color(){
        echo $this->model = "Model 2022";
        echo "Audi Color:  Silver Gray Ash! ";
    }
    public function door()
    {
        echo "Audi has 5 door!";
    }
}

$Audi22 = new Audi();
$Audi22->color();
$Audi22->door();
echo $Audi22->model;

?>
