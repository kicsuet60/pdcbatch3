<?php
// include '../classes/Car1.php';
// include '../classes/Car2.php';
// include '../classes/Car3.php';

function __autoload($car)
{
    include '../classes/'.$car.'.php';    
}

$car1 = new Car1;
echo "<br>";
$car2 = new Car2;
echo "<br>";
$car3 = new Car3;

?>
