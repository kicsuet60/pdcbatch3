<?php
 //public
//  class User{
//     public $email;
//     public $password;

//     public function __construct($e, $p)
//     {
//         $this->email = $e;
//         $this->password = $p;
//     }
// }
// class Admin extends User{
//     public function getEmail(){
//         return $this->email . $this->password;
//     }
// }
// $obj = new Admin('test@gmail.com','123456');
// echo $obj->getEmail();


//protected
// class User{
//     private $email;
//     public $password;
//     const abc = "KicsUet";

//     public function __construct($e, $p)
//     {
//         $this->email = $e;
//         $this->password = $p;
//     }
// }
// class Admin extends User{
//     public function getEmail(){
//         return $this->email;
//     }
// }
// $obj = new Admin('test@gmail.com','123456');
// echo $obj->getEmail();
// echo $obj->email;
// echo $obj->password;
// echo User::abc;


?>