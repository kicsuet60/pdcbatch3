<?php 
// interface Demo{
//     public function test1();
//     public function test2();
// }
// interface Demo2{
//     public function test3();
// }
// class childClass implements Demo, Demo2 {
//     public function test1()
//     {
//         echo "I am test1 method";
//     }
//     public function test2()
//     {
//         echo "I am test2 method";
//     }
//     public function test3()
//     {
//         echo "I am test3 method";
//     }
// }

// $iaminterface = new childClass();
// $iaminterface->test1();
