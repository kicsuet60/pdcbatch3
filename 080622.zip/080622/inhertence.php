<?php


class Vehiche {
   public $name;
   public function __construct($modelname)
    {
        $this->name = $modelname;
    }
    public function start(){
        echo $this->name . " Enagine Start";
    }
    public function drive(){
        echo $this->name . " Lets go for drive";
    }    
}

class Car extends Vehiche {

}
class Motercycle extends Vehiche {
    public function drive(){
        echo $this->name . " Lets go for Ride!";
    }
    public function start(){
        echo $this->name . " Enagine Start after beep!";
    }
}

$audi = new Car('audi-8');
$audi->start();
echo "<br/>";
$bmw = new Motercycle('bmw-2');
$bmw->start();
echo "<br/>";
$bmw->drive();
echo "<br/>";

?>