<!-- __CLASS__ -->

<?php 
class Car {
    private $model = '';
    // The constructor
    public function __construct($model = null)
    {
        if($model)
        {
            $this -> model = $model;
        }
    }
    public function getCarModel()
    {
   
        return " The <b>" . __class__ . "</b> model is: " . $this -> model;
    }
}
$car1 = new Car();
echo $car1 -> getCarModel();

// __LINE__ to get the line number in which the constant is used.
// __FILE__ to get the full path or the filename in which the constant is used.
// __METHOD__ to get the name of the method in which the constant is used.
?>