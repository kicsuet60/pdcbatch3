// string
let firstName = "Arif";
let lastName = "Ali";

let email = "tahir.shafi@kics.edu.pki";

// console.log(firstName, lastName, email);

// string concatenation

let fullName = firstName + " " + lastName;
// let fullName = firstName + lastName;
// console.log(fullName);
console.log(typeof fullName);
// console.log(email[3]);
// console.log(email.length);

// console.log(fullName.toUpperCase());
// console.log(fullName.toLowerCase());

let user = fullName.toLowerCase();
// console.log(user);
// console.log(fullName);
// console.log(email.indexOf("i"));

// index of the p letter:'21

// console.log(email.lastIndexOf("i"));
// console.log(email.slice(1, 5));
console.log(email.replace("i", "-"));
