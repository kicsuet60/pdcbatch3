// const presentStudents = [12, 13, 15, 0, 16, 17, 22, 25, 1, 2];
// for (let i = 0; i < presentStudents.length; i++) {
//   if (presentStudents[i] === 0) {
//     continue;
//   }
//   console.log("Class present student: ", presentStudents[i]);
//   if (presentStudents[i] === 25) {
//     console.log("Attendence Complete!");
//     break;
//   }
// }

////////////////////////////////////////

// const grade = "G";

// switch (grade) {
//   case "A":
//     console.log("your grade A!");
//     break;
//   case "B":
//     console.log("you achived grade B!");
//     break;
//   case "C":
//     console.log("you achived grade C!");
//     break;
//   case "D":
//     console.log("you achived grade D!");
//     break;
//   default:
//     console.log("you achived grade F!");
//     break;
// }
