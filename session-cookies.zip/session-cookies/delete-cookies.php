<?php
ob_start();

setcookie('username', '', time() - 60 * 60 * 24);
setcookie('firstname', '', time() - 60 * 60 * 24);
