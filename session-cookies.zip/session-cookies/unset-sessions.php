<?php
ob_clean();

session_start();

session_destroy();
// unset($_SESSION['name']);
echo $_SESSION['name'];
?>