<?php
ob_start();
session_start();

$_SESSION['name'] = "Arif";
$_SESSION['username'] = "Sultan";

echo $_SESSION['name'];
echo $_SESSION['username'];

?>