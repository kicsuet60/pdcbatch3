<?php
ob_start();

setcookie('username', 'Arif', time() + 60 * 60 * 24);
// setcookie('username', 'Arif', time() + 6);
setcookie('firstname', 'Ali', time() + 60 * 60 * 24);

echo $_COOKIE['username'];
echo $_COOKIE['firstname'];
?>