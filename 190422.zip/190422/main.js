let user = {
  name: "tahir",
  age: 30,
  email: "tahir.shafi@kics.edu.pk",
  location: "lahore",
  blog: ["objects in javascript", "calculator in javascript"],
  login() {
    console.log("now user login.");
  },
  logout() {
    console.log("user logout.");
  },
  logblogs() {
    // console.log("this user has written these blogs:");
    console.log(this);
  },
};

// console.log(user.name);
user.logblogs();
